package com.drivequeen.driver.Listeners;

/**
 * Created by Appoets on 03-02-2017.
 */

public interface ConnectionBooleanChangedListener {
    public void OnMyBooleanChanged();
}
